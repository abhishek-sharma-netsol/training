﻿namespace EmployeeLinqTest.Models
{
    public class EmployeeModel
    {
        public int EmpId { get; set; } 

        public string EmpName { get; set; }

        public int EmpAge { get; set; }

        public string EmpEmail { get; set; }

        public string EmpFathername { get; set; }

        public string EmpMothername { get; set; }

        public int EmpSalary { get; set; }

    }
}
